# Cheap AI Chess!

A Pen created on CodePen.

Original URL: [https://codepen.io/jak_e/pen/JjRGQPY](https://codepen.io/jak_e/pen/JjRGQPY).

A wonderful opportunity to beat a computer at chess!

Play against a friend, a totally random AI, or wager money as it plays against itself. I'm sure there are still bugs in here but hey, happy new year.